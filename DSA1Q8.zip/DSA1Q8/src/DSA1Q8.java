import java.util.Arrays;
public class DSA1Q8 {
	 public static int[] findErrorNums(int[] nums) {
	        int ans[] = {-1,-1};
	        for(int i=0;i<nums.length;i++)
	        {
	            int curr=Math.abs(nums[i])-1;
	            if(nums[curr]<0)
	                ans[0] = curr + 1;
	            else
	                nums[curr] = nums[curr] * -1;
	        }
	        for(int i=0;i<nums.length;i++)
	        {
	            if(nums[i]>0)
	                ans[1] = i + 1;
	        }
	        return ans;
	    }
	

	public static void main(String[] args) {
		int arr[]= {1,2,2,4};
		int result[]= findErrorNums(arr);
		//System.out.println("Duplicate Number: " + result[0]); // Output: Duplicate Number: 2
       // System.out.println("Missing Number: " + result[1]); // Output: Missing Number: 3

        for (int i=0; i<=1; i++) {
        	System.out.print(result[i]+", ");
        }
	}
	

}
