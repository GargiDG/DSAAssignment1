
public class DsaQ1Q2 {

	 public static int removeElement(int[] nums, int val) {
	        int k = 0; // Number of elements not equal to val
	        
	        // Iterate through the array
	        for (int i = 0; i < nums.length; i++) {
	            // If the current element is not equal to val, move it to the first k positions
	            if (nums[i] != val) {
	                nums[k] = nums[i];
	                k++;
	            }
	        }
	        
	        return k;
	    }
	    
	
	public static void main(String[] args) {
		int arr[] = {3,2,2,3};
		int k = removeElement(arr, 3);
		System.out.println("Number of elements not equal to val is:  "+k);
		 System.out.print("Modified nums: ");
	        for (int i = 0; i < k; i++) {
	            System.out.print(arr[i] + " ");
	        }
	}

}
