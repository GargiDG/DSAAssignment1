
public class DSA1Q7 {
	    public static void moveZeroes(int[] nums) {
	        int insertPos = 0; // Position to insert non-zero elements
	        
	        // Iterate through the array
	        for (int num : nums) {
	            if (num != 0) {
	                nums[insertPos] = num; // Move non-zero element to the current insert position
	                insertPos++; // Increment the insert position
	            }
	        }
	        
	        // Fill the remaining positions with zeros
	        while (insertPos < nums.length) {
	            nums[insertPos] = 0;
	            insertPos++;
	        }
	    }


	public static void main(String[] args) {
		int nums[] = {0,1,0,3,12};
		moveZeroes(nums);
		for(int num : nums) {
			System.out.print(num + " ");
		}
	}

}
