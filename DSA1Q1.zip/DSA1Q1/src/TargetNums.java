import java.util.HashMap;
import java.util.Map;
public class TargetNums {

	 public static int[] twoSum(int[] nums, int target) {
	        // Create a map to store the complement of each number
	        Map<Integer, Integer> complementMap = new HashMap<>();
	        
	        // Iterate through the array
	        for (int i = 0; i < nums.length; i++) {
	            int num = nums[i];
	            int complement = target - num;
	            
	            // Check if the complement exists in the map
	            if (complementMap.containsKey(complement)) {
	                // Return the indices of the two numbers that add up to the target
	                return new int[] { complementMap.get(complement), i };
	            }
	            
	            // Add the current number and its index to the map
	            complementMap.put(num, i);
	        }
	        
	        // If no solution is found, return an empty array
	        return new int[0];
	    }
	
	public static void main(String[] args) {
		int arr[] = {2,7,11,15};       
        int[] n = twoSum(arr, 9);
        int len = n.length;
        System.out.println("Array after pushing zeros to the back: ");
        for (int i=0; i<len; i++)
            System.out.print(i+" ");
	}


	}

