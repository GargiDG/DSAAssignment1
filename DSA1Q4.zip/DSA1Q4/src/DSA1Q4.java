
public class DSA1Q4 {
	
	    public static int[] plusOne(int[] digits) {
	        int n = digits.length;
	        
	        // Iterate through the digits array from right to left
	        for (int i = n - 1; i >= 0; i--) {
	            // Increment the current digit by one
	            digits[i]++;
	            
	            // Check if there is a carry
	            if (digits[i] < 10) {
	                // No carry, so we can return the digits array as it is
	                return digits;
	            }
	            
	            // Carry occurred, set the current digit to 0
	            digits[i] = 0;
	        }
	        
	        // If the loop completes, it means a carry occurred for the leftmost digit
	        // In this case, we need to create a new array with an additional digit
	        int[] result = new int[n + 1];
	        result[0] = 1; // Set the leftmost digit to 1 (carry)
	        
	        return result;
	    }


	public static void main(String[] args) {
		int arr[] = {1,2,3};
		int newArr[] = plusOne(arr);
		for(int n : newArr) {
			 System.out.print(n+" ");
		}
	}

}
